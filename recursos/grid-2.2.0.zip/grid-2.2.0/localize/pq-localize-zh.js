/**
 * @author pdhindsa
 */
jQuery.paramquery.pqGrid.regional['zh'] = {
	strLoading: "加载中",
	strAdd: "添加",
	strEdit: "编辑",
	strDelete: "删除",
	strSearch: "搜索",
	strNothingFound: "暂无结果",
	strNoRows: "暂无结果",
	strSelectedmatches:"选择{0}{1}匹配",
	strPrevResult: "上一结果",
	strNextResult: "下一结果"
}
jQuery.paramquery.pqPager.regional['zh']={
	strPage:"第 {0} 页（共 {1} 页）",
	strFirstPage:"第一页",
	strPrevPage:"上一页",
	strNextPage:"下一页",
	strLastPage:"尾页",
	strRefresh:"刷新",	
	strRpp:"每页记录: {0}",
	strDisplay:"显示第 {0} 到 {1} 条，总共 {2} 条数据"	
}
