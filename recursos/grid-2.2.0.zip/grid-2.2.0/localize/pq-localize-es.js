/**
 * @author pdhindsa
 */
$.paramquery.pqGrid.regional['es'] = {
	strLoading: "Carga",
	strAdd: "añadir",
	strEdit: "editar",
	strDelete: "borrar",
	strSearch: "Buscar",
	strNothingFound: "no he encontrado nada",
	strSelectedmatches:"Selección de {0} de {1} partidos",
	strPrevResult: "Resultado Anterior",
	strNextResult: "Resultado siguiente"	
}
$.paramquery.pqPager.regional['es']={
	strPage:"Página {0} de {1}",
	strFirstPage:"Primera Página",
	strPrevPage:"Página anterior",
	strNextPage:"Página siguiente",
	strLastPage:"Última página",
	strRefresh:"refrescar",	
	strRpp:"Registros por página: {0}",
	strDisplay:"Mostrando {0} a {1} de {2} elementos."	
}
